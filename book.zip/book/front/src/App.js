
import Header from './components/header';

function App() {
  return (
    <div className="App">
     <Header />
    </div>
  );
}

export default App;
