package com.ss.securitydb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecuritydbApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecuritydbApplication.class, args);
	}

}
