INSERT INTO MEMBER (NAME, EMAIL, create_at, update_at) 
VALUES ('BTS', 'bts@kpop.com', '2024-09-19T12:30:00', '2024-09-19T12:30:00');

INSERT INTO MEMBER (NAME, EMAIL, create_at, update_at) 
VALUES ('IU', 'iu@music.com', '2024-09-18T09:45:00', '2024-09-18T09:45:00');

INSERT INTO MEMBER (NAME, EMAIL, create_at, update_at) 
VALUES ('Park Seo-Joon', 'parkseojun@actor.com', '2024-09-17T15:20:00', '2024-09-17T15:20:00');

INSERT INTO MEMBER (NAME, EMAIL, create_at, update_at) 
VALUES ('Kim Tae-Hee', 'kimtaehee@actress.com', '2024-09-16T11:10:00', '2024-09-16T11:10:00');

INSERT INTO MEMBER (NAME, EMAIL, create_at, update_at) 
VALUES ('Lee Min-Ho', 'leeminho@drama.com', '2024-09-15T13:55:00', '2024-09-15T13:55:00');

INSERT INTO book (title, author) VALUES ('자바의 정석', '남궁성');
INSERT INTO book (title, author) VALUES ('스프링부트 따라하기', '코스');
INSERT INTO book (title, author) VALUES ('리액트 프로그래밍', '김철수');
INSERT INTO book (title, author) VALUES ('데이터베이스 기초', '이영희');
INSERT INTO book (title, author) VALUES ('알고리즘 문제 해결', '박지민');

