package com.example.junit.service;

import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
public class MemberServiceTest {

}
